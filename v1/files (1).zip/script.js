'use strict';
/* Emission factors: rounded approximations, see about.html */
const FACTORS = {
  vehicle: { petrol: 0.17, diesel: 0.15, cng: 0.12, ev: 0.08, bike: 0.05 },
  publicTransport: 0.04, flight: 250, electricity: 0.71, lpgCylinder: 42.5, waste: 0.45,
  diet: { veg: 1000, mixed: 1500, non: 1900 }, treePerYear: 21
};
const BENCHMARKS = [['India average', 1.9], ['World average', 4.7], ['Paris-aligned 2030', 2.3]];
const TIPS = {
  Transport: 'Switch short trips to walking, cycling, bus or train, or share rides.',
  Flights: 'Replace one flight with a train journey or a video call where you can.',
  'Home energy': 'Use 5-star appliances and LED lighting, switch off standby loads, and cook with lids on.',
  Food: 'Eat more seasonal, local and plant-based meals and avoid wasting food.',
  Waste: 'Segregate waste, compost kitchen scraps and cut single-use plastic.'
};
const ACTIONS = [
  { id: 'ev', label: 'Switch to an electric vehicle', apply: (v) => ({ ...v, vehicle: 'ev' }) },
  { id: 'transit', label: 'Replace half my car trips with bus or train', apply: (v) => ({ ...v, carKm: v.carKm / 2, pubKm: v.pubKm + v.carKm / 2 }) },
  { id: 'flight', label: 'Take one fewer flight a year', apply: (v) => ({ ...v, flights: Math.max(0, v.flights - 1) }) },
  { id: 'power', label: 'Cut electricity use by 20% (LEDs, efficient AC)', apply: (v) => ({ ...v, kwh: v.kwh * 0.8 }) },
  { id: 'lpg', label: 'Use 20% less cooking gas', apply: (v) => ({ ...v, lpg: v.lpg * 0.8 }) },
  { id: 'veg', label: 'Move to a vegetarian diet', apply: (v) => ({ ...v, diet: 'veg' }) },
  { id: 'waste', label: 'Halve my household waste (compost and recycle)', apply: (v) => ({ ...v, waste: v.waste / 2 }) }
];
const KEYS = { hist: 'carbontrace-history', pledge: 'carbontrace-pledges', theme: 'carbontrace-theme', quiz: 'carbontrace-quiz', social: 'carbontrace-social' };
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage blocked */ } };
function download(name, text, type) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: type || 'text/csv' }));
  a.download = name; document.body.appendChild(a); a.click(); a.remove();
}
async function copyText(text, el) {
  try { await navigator.clipboard.writeText(text); el.textContent = 'Copied to clipboard.'; }
  catch (e) { el.textContent = 'Copy failed. Select the text manually.'; }
}

/* ---------- Calculation ---------- */
function calculate(v) {
  const people = Math.max(1, v.people || 1);
  const parts = {
    Transport: v.carKm * 52 * FACTORS.vehicle[v.vehicle] + v.pubKm * 52 * FACTORS.publicTransport,
    Flights: v.flights * FACTORS.flight,
    'Home energy': (v.kwh * 12 * FACTORS.electricity + v.lpg * FACTORS.lpgCylinder) / people,
    Food: FACTORS.diet[v.diet],
    Waste: v.waste * 52 * FACTORS.waste
  };
  const kg = Object.values(parts).reduce((a, b) => a + b, 0);
  return { parts, kg, tonnes: kg / 1000 };
}
function gradeOf(t) { return t <= 1.5 ? 'A' : t <= 2.3 ? 'B' : t <= 3.5 ? 'C' : t <= 4.7 ? 'D' : 'E'; }
function readInputs() {
  const n = (id) => Number($(id).value);
  return { vehicle: $('vehicle').value, carKm: n('carKm'), pubKm: n('pubKm'), flights: n('flights'), kwh: n('kwh'),
           lpg: n('lpg'), waste: n('waste'), diet: $('diet').value, people: n('people') };
}
function barRow(label, value, pct, cls) {
  return `<div class="bar-row"><div class="lab"><span>${label}</span><span>${value}</span></div><div class="track"><div class="fill ${cls || ''}" style="width:${pct}%"></div></div></div>`;
}

/* ---------- Charts (plain canvas, no libraries) ---------- */
const COLORS = ['#10b981', '#6fa58e', '#fbbf24', '#f97316', '#60a5fa'];
function drawDonut(parts, tonnes) {
  const c = $('donut'), g = c.getContext('2d'), W = c.width, cx = W / 2, R = W / 2 - 8;
  g.clearRect(0, 0, W, W);
  const vals = Object.values(parts), tot = vals.reduce((a, b) => a + b, 0) || 1;
  let a0 = -Math.PI / 2;
  vals.forEach((v, i) => {
    const a1 = a0 + (v / tot) * Math.PI * 2;
    g.beginPath(); g.moveTo(cx, cx); g.arc(cx, cx, R, a0, a1); g.closePath(); g.fillStyle = COLORS[i]; g.fill();
    a0 = a1;
  });
  g.beginPath(); g.arc(cx, cx, R * 0.6, 0, Math.PI * 2); g.fillStyle = '#1b3027'; g.fill();
  g.fillStyle = '#F2F4EA'; g.textAlign = 'center'; g.font = '700 30px sans-serif'; g.fillText(tonnes.toFixed(1) + ' t', cx, cx + 4);
  g.font = '14px sans-serif'; g.fillText('CO₂ per year', cx, cx + 26);
  $('parts').dataset.legend = '1';
}
function drawTrend() {
  const c = $('trend'), g = c.getContext('2d'), W = c.width, H = c.height;
  g.clearRect(0, 0, W, H);
  const ink = getComputedStyle(document.body).color;
  const pts = load(KEYS.hist, []).slice().reverse().map((h) => Number(h.t));
  g.fillStyle = ink; g.font = '16px sans-serif'; g.textAlign = 'center';
  if (pts.length < 2) { g.fillText('Save at least two results to see a trend.', W / 2, H / 2); return; }
  const max = Math.max(...pts, 4.7) * 1.1, pad = 40, step = (W - pad * 2) / (pts.length - 1);
  const y = (t) => H - pad - (t / max) * (H - pad * 2);
  g.strokeStyle = '#6fa58e'; g.setLineDash([6, 6]); g.beginPath(); g.moveTo(pad, y(2.3)); g.lineTo(W - pad, y(2.3)); g.stroke(); g.setLineDash([]);
  g.textAlign = 'left'; g.fillText('2.3 t target', pad + 4, y(2.3) - 6);
  g.strokeStyle = '#059669'; g.lineWidth = 3; g.beginPath();
  pts.forEach((t, i) => (i ? g.lineTo(pad + i * step, y(t)) : g.moveTo(pad, y(t)))); g.stroke();
  pts.forEach((t, i) => { g.beginPath(); g.arc(pad + i * step, y(t), 5, 0, 7); g.fillStyle = '#10b981'; g.fill(); g.fillStyle = ink; g.textAlign = 'center'; g.fillText(t.toFixed(1), pad + i * step, y(t) - 12); });
}

/* ---------- Calculator page ---------- */
function resultText(r) {
  return `My yearly carbon footprint is ${r.tonnes.toFixed(2)} t CO₂ (grade ${gradeOf(r.tonnes)}). Calculate yours with Carbotrack:`;
}
function renderPlanner(v, base) {
  const pledged = load(KEYS.pledge, []);
  $('planner').innerHTML = ACTIONS.map((a) => {
    const sv = base.kg - calculate(a.apply(v)).kg;
    return `<label class="chk"><input type="checkbox" data-id="${a.id}" ${pledged.includes(a.id) ? 'checked' : ''}><span>${a.label}</span><span class="sv">saves ${Math.round(sv)} kg/yr</span></label>`;
  }).join('');
  const after = ACTIONS.filter((a) => pledged.includes(a.id)).reduce((acc, a) => a.apply(acc), v);
  const r2 = calculate(after), saved = base.kg - r2.kg;
  $('pbar').style.width = (base.kg ? Math.min(100, Math.round(saved / base.kg * 100)) : 0) + '%';
  $('psum').textContent = pledged.length
    ? `Your pledges would save about ${Math.round(saved)} kg a year (${base.kg ? Math.round(saved / base.kg * 100) : 0}%), bringing you to ${r2.tonnes.toFixed(2)} t.`
    : 'No pledges yet. Tick an action above to see your new footprint.';
}
function renderShare(r) {
  const url = encodeURIComponent(location.href.replace(/calculator\.html.*/, 'index.html')), txt = encodeURIComponent(resultText(r));
  const L = [['WhatsApp', `https://wa.me/?text=${txt}%20${url}`], ['X', `https://twitter.com/intent/tweet?text=${txt}&url=${url}`],
    ['LinkedIn', `https://www.linkedin.com/sharing/share-offsite/?url=${url}`], ['Facebook', `https://www.facebook.com/sharer/sharer.php?u=${url}`],
    ['Telegram', `https://t.me/share/url?url=${url}&text=${txt}`]];
  $('share').innerHTML = L.map(([n, h]) => `<a href="${h}" target="_blank" rel="noopener">${n}</a>`).join('');
}
function render() {
  const v = readInputs();
  ['carKm', 'pubKm', 'flights', 'kwh', 'lpg', 'waste', 'people'].forEach((k) => { $('o-' + k).textContent = v[k]; });
  const r = calculate(v), t = r.tonnes;
  $('total').textContent = t.toFixed(2);
  $('grade').textContent = 'Eco grade ' + gradeOf(t);
  $('verdict').textContent = t <= 2.3 ? 'At or below a Paris-aligned level. Keep it up.' : t <= 4.7 ? 'Below the world average, but above the 2030 target.' : 'Above the world average. Small changes will help a lot.';
  $('trees').textContent = `About ${Math.ceil(r.kg / FACTORS.treePerYear)} trees would be needed to absorb this in a year.`;
  const entries = Object.entries(r.parts);
  $('parts').innerHTML = entries.map(([k, kg], i) => barRow(`<span style="color:${COLORS[i]}">●</span> ${k}`, Math.round(kg) + ' kg', r.kg ? Math.round(kg / r.kg * 100) : 0)).join('');
  const rows = [['You', t]].concat(BENCHMARKS), max = Math.max(...rows.map((x) => x[1]), 0.1);
  $('compare').innerHTML = rows.map(([k, x]) => barRow(k, x.toFixed(1) + ' t', Math.round(x / max * 100), 'cmp')).join('');
  const top = entries.slice().sort((a, b) => b[1] - a[1])[0];
  $('tip').innerHTML = `<b>Start here:</b> ${top[0]} is your largest source. ${TIPS[top[0]]}`;
  drawDonut(r.parts, t); renderPlanner(v, r); renderShare(r); drawTrend();
}
function renderHistory() {
  const list = load(KEYS.hist, []);
  $('history').innerHTML = list.length ? list.map((h) => `<li>${esc(h.date)}: <b>${esc(h.t)} t CO₂</b></li>`).join('') : '<li class="small">Nothing saved yet.</li>';
}
function initCalculator() {
  document.querySelectorAll('#calcForm input, #calcForm select').forEach((el) => el.addEventListener('input', render));
  $('planner').addEventListener('change', (e) => {
    const id = e.target.dataset.id; if (!id) return;
    const s = new Set(load(KEYS.pledge, [])); e.target.checked ? s.add(id) : s.delete(id);
    save(KEYS.pledge, [...s]); render();
  });
  $('saveBtn').addEventListener('click', () => {
    const list = load(KEYS.hist, []);
    list.unshift({ date: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }), t: calculate(readInputs()).tonnes.toFixed(2) });
    save(KEYS.hist, list.slice(0, 12)); renderHistory(); drawTrend();
  });
  $('clearBtn').addEventListener('click', () => { save(KEYS.hist, []); renderHistory(); drawTrend(); });
  $('resetBtn').addEventListener('click', () => { $('calcForm').reset(); render(); });
  $('copyBtn').addEventListener('click', () => copyText(resultText(calculate(readInputs())) + ' ' + location.origin, $('msg')));
  if (!navigator.share) $('nativeShare').style.display = 'none';
  $('nativeShare').addEventListener('click', () => navigator.share({ title: 'Carbotrack', text: resultText(calculate(readInputs())), url: location.href }).catch(() => {}));
  $('csvBtn').addEventListener('click', () => {
    const rows = load(KEYS.hist, []);
    download('carbon-history.csv', 'date,tonnes_co2\n' + rows.map((h) => `"${h.date}",${h.t}`).join('\n'));
  });
  $('printBtn').addEventListener('click', () => window.print());
  render(); renderHistory();
}

/* ---------- Quiz ---------- */
const QUIZ = [
  { q: 'Which gas contributes most to human-caused global warming?', o: ['Oxygen', 'Carbon dioxide', 'Nitrogen', 'Argon'], a: 1, e: 'Carbon dioxide from burning fossil fuels is the largest contributor.' },
  { q: 'Which usually emits the least CO₂ per passenger-km?', o: ['Petrol car with one person', 'Domestic flight', 'Train', 'Diesel SUV'], a: 2, e: 'Trains carry many people efficiently, so emissions per passenger are low.' },
  { q: 'About how much CO₂ does a mature tree absorb in a year?', o: ['2 kg', '21 kg', '210 kg', '2,100 kg'], a: 1, e: 'Roughly 21 kg a year is a commonly used estimate, which is why cutting emissions beats relying on trees alone.' },
  { q: 'Where should a banana peel go?', o: ['Dry waste', 'Hazardous waste', 'Wet (biodegradable) waste', 'E-waste'], a: 2, e: 'Kitchen scraps are biodegradable and can be composted.' },
  { q: 'Which bulb uses the least electricity for the same light?', o: ['Incandescent', 'Halogen', 'LED', 'Candle'], a: 2, e: 'LEDs use far less power than incandescent or halogen bulbs.' },
  { q: 'What does the Paris Agreement aim to limit warming to?', o: ['Well below 2 °C', 'Below 5 °C', 'Below 4 °C', 'Below 3 °C'], a: 0, e: 'It aims for well below 2 °C, pursuing 1.5 °C.' },
  { q: 'Which diet generally has the lowest footprint?', o: ['Meat-heavy', 'Mixed', 'Plant-based', 'They are all equal'], a: 2, e: 'Plant-based diets generally cause fewer emissions than meat-heavy ones.' },
  { q: 'Which is a renewable energy source?', o: ['Coal', 'Natural gas', 'Solar', 'Petrol'], a: 2, e: 'Solar energy is replenished naturally and produces no CO₂ while generating power.' }
];
function initQuiz() {
  const box = $('quizBox'); let i = 0, score = 0;
  function show() {
    if (i >= QUIZ.length) {
      const best = Math.max(score, load(KEYS.quiz, 0)); save(KEYS.quiz, best);
      const badge = score >= 7 ? 'Eco Champion' : score >= 5 ? 'Green Learner' : 'Eco Beginner';
      box.innerHTML = `<h2>Your score: ${score} / ${QUIZ.length}</h2><p class="lead">Badge: <b>${badge}</b>. Best score: ${best}.</p><button class="btn" id="again">Try again</button>`;
      $('again').addEventListener('click', () => { i = 0; score = 0; show(); }); return;
    }
    const Q = QUIZ[i];
    box.innerHTML = `<p class="small">Question ${i + 1} of ${QUIZ.length}</p><h2 style="font-size:26px">${Q.q}</h2>` +
      Q.o.map((o, k) => `<button class="opt" data-k="${k}">${o}</button>`).join('') + '<p id="fb"></p><div id="nx"></div>';
    box.querySelectorAll('.opt').forEach((b) => b.addEventListener('click', () => {
      const k = Number(b.dataset.k); if (k === Q.a) score++;
      box.querySelectorAll('.opt').forEach((x) => { x.disabled = true; if (Number(x.dataset.k) === Q.a) x.classList.add('right'); });
      if (k !== Q.a) b.classList.add('wrong');
      $('fb').textContent = (k === Q.a ? 'Correct. ' : 'Not quite. ') + Q.e;
      $('nx').innerHTML = `<button class="btn" id="next">${i === QUIZ.length - 1 ? 'See score' : 'Next question'}</button>`;
      $('next').addEventListener('click', () => { i++; show(); });
    }));
  }
  show();
}

/* ---------- Social media tracker ---------- */
function initTracker() {
  $('tDate').valueAsDate = new Date();
  const num = (id) => Math.max(0, Number($(id).value) || 0);
  function draw() {
    const L = load(KEYS.social, []), sum = (k) => L.reduce((a, p) => a + p[k], 0);
    $('tBody').innerHTML = L.length ? L.map((p, i) => `<tr><td>${i + 1}</td><td>${esc(p.plat)}</td><td><a href="${esc(p.url)}" target="_blank" rel="noopener">Open</a></td><td>${esc(p.date)}</td><td>${p.views}</td><td>${p.likes}</td><td>${p.shares}</td><td>${p.com}</td><td><button class="del" data-i="${i}" aria-label="Delete post ${i + 1}">Delete</button></td></tr>`).join('') : '<tr><td colspan="9">No posts added yet.</td></tr>';
    $('tFoot').innerHTML = L.length ? `<tr><th colspan="4">Total (${L.length} posts)</th><th>${sum('views')}</th><th>${sum('likes')}</th><th>${sum('shares')}</th><th>${sum('com')}</th><th></th></tr>` : '';
  }
  $('tAdd').addEventListener('click', () => {
    const url = $('tUrl').value.trim();
    if (!/^https?:\/\//i.test(url)) { $('tMsg').textContent = 'Enter a valid link starting with https://'; return; }
    const L = load(KEYS.social, []);
    L.push({ plat: $('tPlat').value, url, date: $('tDate').value, views: num('tViews'), likes: num('tLikes'), shares: num('tShares'), com: num('tCom') });
    save(KEYS.social, L); $('tUrl').value = ''; $('tMsg').textContent = 'Post added.'; draw();
  });
  $('tBody').addEventListener('click', (e) => {
    const i = e.target.dataset.i; if (i === undefined) return;
    const L = load(KEYS.social, []); L.splice(Number(i), 1); save(KEYS.social, L); draw();
  });
  const rows = () => load(KEYS.social, []);
  $('tCopy').addEventListener('click', () => copyText('S.No\tPlatform\tLink\tDate\tViews\tLikes\tShares\tComments\n' + rows().map((p, i) => [i + 1, p.plat, p.url, p.date, p.views, p.likes, p.shares, p.com].join('\t')).join('\n'), $('tMsg')));
  $('tCsv').addEventListener('click', () => download('social-media-coverage.csv', 'platform,link,date,views,likes,shares,comments\n' + rows().map((p) => [p.plat, p.url, p.date, p.views, p.likes, p.shares, p.com].join(',')).join('\n')));
  draw();
}

/* ---------- Shared: theme and nav ---------- */
function applyTheme(t) { document.documentElement.setAttribute('data-theme', t); }
function initTheme() {
  const saved = load(KEYS.theme, null);
  applyTheme(saved || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  $('themeBtn').addEventListener('click', () => {
    const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    applyTheme(next); save(KEYS.theme, next); if ($('trend')) drawTrend();
  });
}
function initNav() {
  const btn = $('menuBtn'), links = $('links');
  btn.addEventListener('click', () => { const open = links.classList.toggle('open'); btn.setAttribute('aria-expanded', String(open)); });
}
document.addEventListener('DOMContentLoaded', () => {
  initNav(); initTheme();
  if ($('calcForm')) initCalculator();
  if ($('quizBox')) initQuiz();
  if ($('tForm')) initTracker();
});
